from models.client_models import model_customers as model
from controllers.controller_utils import serialize, validate_id, validate_data

def add_customer_controller(first_name, last_name, address, phone, email, password, customer_code=None):
    required = (first_name, last_name, email, password)
    if not all(isinstance(value, str) and value.strip() for value in required):
        raise ValueError("Missing required customer information")
    if password.strip() == "":
        raise ValueError("Password cannot be empty")
    return model.add_customer(first_name, last_name, address, phone, email, password, customer_code)

def get_customer_controller(customer_id):
    return serialize(model.get_customer(validate_id(customer_id, "customer ID")))

def get_customer_by_email_controller(email):
    if not isinstance(email, str) or not email.strip():
        raise ValueError("Invalid email")
    return serialize(model.get_customer_by_email(email))

def get_all_customers_controller():
    return serialize(model.get_all_customers())

def update_customer_controller(customer_id, values):
    return model.update_customer(validate_id(customer_id, "customer ID"), validate_data(values))

def delete_customer_controller(customer_id):
    return model.delete_customer(validate_id(customer_id, "customer ID"))